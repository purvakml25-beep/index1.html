# Personal Expense Tracker — Web Version

A responsive Flask web app with SQLite storage. It includes:
- Add income and expense transactions
- View and search records
- Filter by transaction type and month
- Edit and delete transactions
- Total income, total expenses, balance and monthly totals
- Export all transactions as CSV
- Input validation and a responsive dashboard

## Run on your computer
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`
4. Run `python app.py`
5. Open `http://127.0.0.1:5000`

## Deploy on Render
1. Upload the contents of this folder to a GitHub repository.
2. In Render, choose **New + → Web Service** and connect the repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Deploy. Render will provide a public URL.

`render.yaml` is included as a deployment blueprint.

## Important database note
This starter version uses SQLite in a local file named `expenses.db`. On hosting plans with an ephemeral filesystem, data can be lost when the service is restarted or redeployed. For long-term records, connect a managed PostgreSQL database or configure persistent storage supported by your hosting plan. Do not store sensitive financial details in a demo deployment.
