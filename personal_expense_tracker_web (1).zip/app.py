from flask import Flask, render_template, request, redirect, url_for, flash, make_response
import sqlite3
import os
import csv
import io
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "expenses.db"))

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL CHECK(type IN ('Income', 'Expense')),
                amount REAL NOT NULL CHECK(amount > 0),
                category TEXT NOT NULL,
                date TEXT NOT NULL,
                description TEXT DEFAULT ''
            )
        """)
        conn.commit()

def validate_form(form):
    t_type = form.get("type", "").strip().title()
    amount_text = form.get("amount", "").strip()
    category = form.get("category", "").strip()
    date_text = form.get("date", "").strip()
    description = form.get("description", "").strip()

    if t_type not in ("Income", "Expense"):
        return None, "Please choose Income or Expense."
    try:
        amount = round(float(amount_text), 2)
        if amount <= 0:
            return None, "Amount must be greater than zero."
    except (ValueError, TypeError):
        return None, "Please enter a valid amount."
    if not category:
        return None, "Please enter a category."
    try:
        parsed_date = datetime.strptime(date_text, "%Y-%m-%d")
        date_text = parsed_date.strftime("%Y-%m-%d")
    except ValueError:
        return None, "Please choose a valid date."
    return {
        "type": t_type,
        "amount": amount,
        "category": category,
        "date": date_text,
        "description": description
    }, None

@app.route("/")
def index():
    search = request.args.get("search", "").strip()
    kind = request.args.get("kind", "All")
    month = request.args.get("month", "").strip()
    query = "SELECT * FROM transactions WHERE 1=1"
    params = []
    if search:
        query += " AND (LOWER(category) LIKE ? OR LOWER(description) LIKE ?)"
        params.extend([f"%{search.lower()}%", f"%{search.lower()}%"])
    if kind in ("Income", "Expense"):
        query += " AND type = ?"
        params.append(kind)
    if month:
        try:
            datetime.strptime(month, "%Y-%m")
            query += " AND substr(date, 1, 7) = ?"
            params.append(month)
        except ValueError:
            month = ""
    query += " ORDER BY date DESC, id DESC"

    with get_db() as conn:
        transactions = conn.execute(query, params).fetchall()
        totals = conn.execute("""
            SELECT
                COALESCE(SUM(CASE WHEN type='Income' THEN amount ELSE 0 END), 0) AS income,
                COALESCE(SUM(CASE WHEN type='Expense' THEN amount ELSE 0 END), 0) AS expense,
                COUNT(*) AS count
            FROM transactions
        """).fetchone()
        month_totals = conn.execute("""
            SELECT
                COALESCE(SUM(CASE WHEN type='Income' THEN amount ELSE 0 END), 0) AS income,
                COALESCE(SUM(CASE WHEN type='Expense' THEN amount ELSE 0 END), 0) AS expense
            FROM transactions
            WHERE substr(date, 1, 7) = ?
        """, (datetime.now().strftime("%Y-%m"),)).fetchone()

    return render_template(
        "index.html",
        transactions=transactions,
        income=totals["income"],
        expense=totals["expense"],
        balance=totals["income"] - totals["expense"],
        count=totals["count"],
        month_income=month_totals["income"],
        month_expense=month_totals["expense"],
        search=search,
        kind=kind,
        month=month,
        today=datetime.now().strftime("%Y-%m-%d"),
        current_month=datetime.now().strftime("%Y-%m")
    )

@app.route("/add", methods=["POST"])
def add_transaction():
    data, error = validate_form(request.form)
    if error:
        flash(error, "error")
        return redirect(url_for("index"))
    with get_db() as conn:
        conn.execute(
            "INSERT INTO transactions (type, amount, category, date, description) VALUES (?, ?, ?, ?, ?)",
            (data["type"], data["amount"], data["category"], data["date"], data["description"])
        )
        conn.commit()
    flash("Transaction added successfully.", "success")
    return redirect(url_for("index"))

@app.route("/edit/<int:transaction_id>", methods=["GET", "POST"])
def edit_transaction(transaction_id):
    with get_db() as conn:
        transaction = conn.execute("SELECT * FROM transactions WHERE id = ?", (transaction_id,)).fetchone()
        if transaction is None:
            flash("Transaction not found.", "error")
            return redirect(url_for("index"))
        if request.method == "POST":
            data, error = validate_form(request.form)
            if error:
                flash(error, "error")
                return render_template("edit.html", transaction=transaction)
            conn.execute("""
                UPDATE transactions
                SET type=?, amount=?, category=?, date=?, description=?
                WHERE id=?
            """, (data["type"], data["amount"], data["category"], data["date"], data["description"], transaction_id))
            conn.commit()
            flash("Transaction updated successfully.", "success")
            return redirect(url_for("index"))
    return render_template("edit.html", transaction=transaction)

@app.route("/delete/<int:transaction_id>", methods=["POST"])
def delete_transaction(transaction_id):
    with get_db() as conn:
        result = conn.execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))
        conn.commit()
    flash("Transaction deleted." if result.rowcount else "Transaction not found.", "success" if result.rowcount else "error")
    return redirect(url_for("index"))

@app.route("/export")
def export_csv():
    with get_db() as conn:
        rows = conn.execute("SELECT id, type, amount, category, date, description FROM transactions ORDER BY date DESC, id DESC").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "Type", "Amount (INR)", "Category", "Date", "Description"])
    for row in rows:
        writer.writerow([row["id"], row["type"], f'{row["amount"]:.2f}', row["category"], row["date"], row["description"]])
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=expense_tracker_transactions.csv"
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    return response

@app.route("/clear-demo", methods=["POST"])
def clear_demo():
    # Optional helper: only clears all records after explicit confirmation in the UI.
    with get_db() as conn:
        conn.execute("DELETE FROM transactions")
        conn.commit()
    flash("All transactions were cleared.", "success")
    return redirect(url_for("index"))

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
